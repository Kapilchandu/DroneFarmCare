# =============================================
# DroneFarmCare - FINAL DEMO SCRIPT
# =============================================

library(DroneFarmCare)
library(ggplot2)

# -----------------------------
# STEP 1: GENERATE DATA
# -----------------------------
data <- data.frame(
  x = runif(300, 0, 100),
  y = runif(300, 0, 100),
  health = runif(300, 0, 1)
)

# -----------------------------
# STEP 2: RUN MAIN SYSTEM
# -----------------------------
result <- dronefarmcare(data)
data <- result$processed_data

# -----------------------------
# STEP 3: FIELD HEALTH MAP
# -----------------------------
ggplot(data, aes(x, y, color = health)) +
  geom_point(size = 2) +
  scale_color_gradient(low = "red", high = "green") +
  ggtitle("Crop Health Map") +
  theme_minimal()

# -----------------------------
# STEP 4: ZONE DISTRIBUTION
# -----------------------------
zone_df <- as.data.frame(table(data$zone))
colnames(zone_df) <- c("zone", "count")

ggplot(zone_df, aes(x = factor(zone), y = count)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  ggtitle("Zone Distribution") +
  theme_minimal()

# -----------------------------
# STEP 5: AVERAGE HEALTH
# -----------------------------
avg <- average_crop_health(data)

ggplot(avg, aes(x = factor(zone), y = health)) +
  geom_bar(stat = "identity", fill = "green") +
  ggtitle("Average Crop Health") +
  theme_minimal()

# -----------------------------
# STEP 6: VARIABILITY (FIXED)
# -----------------------------
var <- aggregate(health ~ zone, data, sd)

ggplot(var, aes(x = factor(zone), y = health)) +
  geom_bar(stat = "identity", fill = "orange") +
  ggtitle("Crop Variability (SD)") +
  ylab("Standard Deviation") +
  theme_minimal()

# -----------------------------
# STEP 7: CLASSIFICATION
# -----------------------------
zones <- classify_crop_zones(data)

ggplot(zones, aes(x = factor(zone), fill = status)) +
  geom_bar() +
  ggtitle("Zone Classification") +
  theme_minimal()

# -----------------------------
# STEP 8: FARMER ACTIONS
# -----------------------------
actions <- recommend_actions(data)

ggplot(actions, aes(x = factor(zone), fill = water)) +
  geom_bar() +
  ggtitle("Water Requirement by Zone") +
  theme_minimal()

# -----------------------------
# STEP 9: PRIORITY ZONES
# -----------------------------
priority <- priority_zones(data)

ggplot(priority, aes(x = factor(zone), fill = priority)) +
  geom_bar() +
  ggtitle("Priority Zones") +
  theme_minimal()

# -----------------------------
# STEP 10: DRONE OPTIMIZATION
# -----------------------------
drones <- estimate_drones_required(data)

plot(drones$wss, type = "b",
     main = "Drone Optimization",
     xlab = "Number of Drones",
     ylab = "WSS")

# -----------------------------
# STEP 11: COVERAGE
# -----------------------------
coverage <- drone_coverage(data, drones$optimal_drones)
print(paste("Coverage per drone:", coverage))

# -----------------------------
# STEP 12: YIELD
# -----------------------------
yield <- estimate_yield(data)
print(paste("Estimated Yield:", yield))

# -----------------------------
# STEP 13: SIMULATION
# -----------------------------
sim <- simulate_crop_health(data, 30)

plot(table(sim),
     main = "Simulated Future Crop Conditions",
     xlab = "Zone",
     ylab = "Frequency")

