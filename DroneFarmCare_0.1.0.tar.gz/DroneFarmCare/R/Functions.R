# =============================================
# DroneFarmCare - FINAL STABLE VERSION
# =============================================

# -----------------------------
# 1. CLUSTERING
# -----------------------------

#' Analyze Crop Health Using Clustering
#' @export
analyze_crop_health <- function(data, k = 3) {
  model <- stats::kmeans(data[, c("x", "y", "health")], centers = k)
  data$zone <- model$cluster
  return(data)
}

# -----------------------------
# INTERNAL HELPER (IMPORTANT)
# -----------------------------

ensure_zone <- function(data){
  if(!"zone" %in% colnames(data)){
    data <- analyze_crop_health(data)
  }
  return(data)
}

# -----------------------------
# 2. HEALTH ANALYSIS
# -----------------------------

#' Average Health per Zone
#' @export
average_crop_health <- function(data) {
  data <- ensure_zone(data)
  stats::aggregate(health ~ zone, data, mean)
}

#' Crop Variability
#' @export
crop_variability <- function(data) {
  data <- ensure_zone(data)
  stats::aggregate(
    health ~ zone,
    data,
    function(x) c(sd = stats::sd(x), var = stats::var(x))
  )
}

# -----------------------------
# 3. CLASSIFICATION
# -----------------------------

#' Classify Crop Zones
#' @export
classify_crop_zones <- function(data) {
  data <- ensure_zone(data)
  
  df <- average_crop_health(data)
  
  df$status <- ifelse(df$health < 0.4, "Critical",
                      ifelse(df$health < 0.7, "Moderate", "Healthy"))
  
  return(df)
}

# -----------------------------
# 4. DECISION SYSTEM
# -----------------------------

#' Recommend Actions
#' @export
recommend_actions <- function(data) {
  df <- classify_crop_zones(data)
  
  df$water <- ifelse(df$status == "Critical", "High",
                     ifelse(df$status == "Moderate", "Medium", "Low"))
  
  df$fertilizer <- df$water
  
  df$treatment <- ifelse(df$status == "Critical", "Immediate",
                         ifelse(df$status == "Moderate", "Monitor", "None"))
  
  return(df)
}

# -----------------------------
# 5. DRONE OPTIMIZATION
# -----------------------------

#' Estimate Number of Drones Required
#' @export
estimate_drones_required <- function(data, max_drones = 10) {
  
  wss <- sapply(1:max_drones, function(k) {
    stats::kmeans(data[, c("x", "y")], centers = k)$tot.withinss
  })
  
  optimal <- which.min(wss)
  
  return(list(
    optimal_drones = optimal,
    wss = wss
  ))
}

#' Drone Coverage Area
#' @export
drone_coverage <- function(data, drones) {
  area <- (max(data$x) - min(data$x)) * (max(data$y) - min(data$y)
  )
  return(area / drones)
}

#' Priority Zones
#' @export
priority_zones <- function(data) {
  df <- classify_crop_zones(data)
  
  df$priority <- ifelse(df$status == "Critical", "High",
                        ifelse(df$status == "Moderate", "Medium", "Low"))
  
  return(df)
}

# -----------------------------
# 6. YIELD
# -----------------------------

#' Estimate Yield
#' @export
estimate_yield <- function(data) {
  mean(data$health) * 100
}

# -----------------------------
# 7. FINAL REPORT
# -----------------------------

#' Generate Farm Report
#' @export
farm_report <- function(data) {
  
  data <- ensure_zone(data)
  
  avg <- average_crop_health(data)
  var <- crop_variability(data)
  status <- classify_crop_zones(data)
  actions <- recommend_actions(data)
  drones <- estimate_drones_required(data)
  priority <- priority_zones(data)
  yield <- estimate_yield(data)
  
  final <- merge(avg, status[, c("zone", "status")], by = "zone")
  final <- merge(final,
                 actions[, c("zone", "water", "fertilizer", "treatment")],
                 by = "zone")
  
  return(list(
    zone_summary = final,
    variability = var,
    recommendations = actions,
    priority_zones = priority,
    drone_plan = drones,
    estimated_yield = yield
  ))
}

# -----------------------------
# 8. MAIN FUNCTION
# -----------------------------

#' Run DroneFarmCare System
#' @export
dronefarmcare <- function(data, k = 3) {
  
  data <- analyze_crop_health(data, k)
  
  report <- farm_report(data)
  
  return(list(
    processed_data = data,
    report = report
  ))
}


# -----------------------------
# 9. SIMULATION
# -----------------------------

#' Simulate Future Crop Conditions
#' @export
simulate_crop_health <- function(data, days = 30) {
  
  data <- ensure_zone(data)
  
  probs <- stats::aggregate(health ~ zone, data, sum)
  probs$prob <- probs$health / sum(probs$health)
  
  sample(probs$zone,
         size = days,
         replace = TRUE,
         prob = probs$prob)
}